"""
Cloud Storage Manager Package
"""
from .storage_provider import StorageProvider
__all__ = ['StorageProvider']